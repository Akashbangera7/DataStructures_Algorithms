package com.company;

import java.util.NoSuchElementException;

public class ArrayQueue {
    private Employee employeeQueue[];
    private int front;
    private int back;

    public ArrayQueue(int capacity){
        employeeQueue = new Employee[capacity];
    }

    public void Add(Employee employee){
        if(back == employeeQueue.length){
            Employee newArray[] = new Employee[2 * employeeQueue.length];
            System.arraycopy(employeeQueue, 0, newArray, 0, employeeQueue.length);
            employeeQueue = newArray;
        }
        employeeQueue[back] = employee;
        back++;
    }

    public Employee Remove(){
        if(size() == 0){
            throw new NoSuchElementException();
        }
        Employee employee = employeeQueue[front];
        front++;
        if(size() == 0){
            front = 0;
            back = 0;
        }
        return employee;
    }

    public Employee peek(){
        if(size() == 0){
            throw new NoSuchElementException();
        }
        return employeeQueue[front];
    }

    public void print(){
        for(int i = front; i < back; i++){
            System.out.println(employeeQueue[i]);
        }
    }

    public int size(){
        return back - front;
    }
}

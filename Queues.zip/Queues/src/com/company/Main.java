package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Employee akash = new Employee("Akash", "Bangera", 100);
        Employee harshita = new Employee("Harshita", "Dekate", 200);
        Employee shalabh = new Employee("Shalabh", "Mittal", 300);
        Employee sujay = new Employee("Sujay", "Joshi", 400);

        ArrayQueue queue = new ArrayQueue(10);

        queue.Add(akash);
        queue.Add(harshita);
        queue.Add(shalabh);
        queue.Add(sujay);

        System.out.println(queue.size());
        queue.print();
        System.out.println("==========================================================");
        queue.Remove();
        System.out.println(queue.size());
        queue.print();
        System.out.println("==========================================================");
        System.out.println(queue.peek());



    }
}
